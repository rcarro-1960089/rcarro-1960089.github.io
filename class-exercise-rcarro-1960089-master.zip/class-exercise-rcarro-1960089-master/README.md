# Book exercises

This repository contains _all_ programming exercises for the [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/) book. 
 
Solutions can be found in the `solution` branch.