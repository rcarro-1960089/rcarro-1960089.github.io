# Chapter 2 Exercises

This repository contains programming exercises for working with the command line, 
based on Chapter 2 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.