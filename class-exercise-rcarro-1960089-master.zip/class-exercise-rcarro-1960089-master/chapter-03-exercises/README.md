# Chapter 3 Exercises

This repository contains programming exercises for using git and GitHub, 
based on Chapter 3 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.