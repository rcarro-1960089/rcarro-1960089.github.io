# Chapter 4 Exercises

This repository contains programming exercises for formatting documents in Markdown, 
based on Chapter 4 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).

Solutions can be found in the `solution` branch.