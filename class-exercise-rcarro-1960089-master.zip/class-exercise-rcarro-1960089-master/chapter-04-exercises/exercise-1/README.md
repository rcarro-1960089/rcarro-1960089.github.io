# Exercise 1
Using the text-edit of your choice (e.g., Atom), create a new file called `README.md`. Alternatively, you may clone this repository and edit this file.

In your `README.md` document, put your favorite quote in a block quote, and provide a link to a website that provides additional information about the quote.

Note that you can preview this Markdown in Atom to make sure it works correctly.


> _“I would sooner be a foreigner in Spain than in most countries. How easy it is to make friends in Spain!”_ – George Orwell
[source](https://takelessons.com/blog/best-travel-quotes-z03)