# Chapter 5 Exercises

This repository contains programming exercises for basic R syntax, 
based on Chapter 5 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.