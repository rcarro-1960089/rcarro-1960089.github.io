# Chapter 6 Exercises

This repository contains programming exercises for working with functions in R, 
based on Chapter 6 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.