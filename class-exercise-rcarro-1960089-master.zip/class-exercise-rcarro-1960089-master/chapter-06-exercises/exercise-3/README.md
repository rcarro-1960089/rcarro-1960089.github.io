# Exercise 3
In this exercise, you'll practice writing and executing basic R functions.

To complete the exercise, open the `exercise-3/exercise.R` file in RStudio, and follow the instructions there.
