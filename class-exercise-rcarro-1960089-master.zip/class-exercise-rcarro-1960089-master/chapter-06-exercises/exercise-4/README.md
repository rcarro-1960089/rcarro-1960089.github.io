# Exercise 4
In this exercise, you'll practice writing functions with conditional statements.

To complete the exercise, open the `exercise-4/exercise.R` file in RStudio, and follow the instructions there.
