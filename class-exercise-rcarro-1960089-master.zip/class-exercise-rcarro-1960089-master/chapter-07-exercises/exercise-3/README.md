# Exercise 3
In this exercise, you'll practice with vector filtering.

To complete the exercise, open the `exercise-3/exercise.R` file in RStudio, and follow the instructions there.
