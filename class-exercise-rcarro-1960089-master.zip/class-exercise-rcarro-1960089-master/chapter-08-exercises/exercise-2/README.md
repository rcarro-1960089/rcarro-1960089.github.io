# Exercise 2
In this exercise, you'll practice using using `*apply()` functions (such as `lapply()`).

To complete the exercise, open the `exercise-2/exercise.R` file in RStudio, and follow the instructions there.
