# Chapter 10 Exercises

This repository contains programming exercises for working with data frames in R, 
based on Chapter 10 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.