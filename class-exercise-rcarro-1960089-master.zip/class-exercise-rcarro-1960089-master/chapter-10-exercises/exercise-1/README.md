# Exercise 1
In this exercise, you'll practice creating data frames in R.

To complete the exercise, open the `exercise-1/exercise.R` file in RStudio, and follow the instructions there.
