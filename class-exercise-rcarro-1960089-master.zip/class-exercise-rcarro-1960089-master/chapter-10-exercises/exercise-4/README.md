# Exercise 4
In this exercise, you'll practice working with an external data set: specifically,education grants awarded by the Gates Foundation between 2008 and 2010.

To complete the exercise, open the `exercise-4/exercise.R` file in RStudio, and follow the instructions there.
