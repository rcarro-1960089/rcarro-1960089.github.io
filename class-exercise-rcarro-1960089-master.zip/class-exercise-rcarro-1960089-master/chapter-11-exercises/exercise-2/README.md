# Exercise 2
In this exercise, you'll practice using `dplyr` to work with data frames in R. Note that this exercise repeats the steps from Exercise 1, but using the `dplyr` package.

To complete the exercise, open the `exercise-2/exercise.R` file in RStudio, and follow the instructions there.
