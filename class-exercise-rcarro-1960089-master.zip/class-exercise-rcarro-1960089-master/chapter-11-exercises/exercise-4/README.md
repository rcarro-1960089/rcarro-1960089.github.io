# Exercise 4
In this exercise, you'll practice using the `dplyr` package to ask questions of a data set: specifically, airline on-time data for flights departing NYC in 2013 from the [`nycflights13`](https://cran.r-project.org/web/packages/nycflights13/index.html) package.

To complete the exercise, open the `exercise-4/exercise.R` file in RStudio, and follow the instructions there.
