# Exercise 5
In this exercise, you'll practice using the dplyr's grouped operations on the [`nycflights13`](https://cran.r-project.org/web/packages/nycflights13/index.html) data set.

To complete the exercise, open the `exercise-5/exercise.R` file in RStudio, and follow the instructions there.
