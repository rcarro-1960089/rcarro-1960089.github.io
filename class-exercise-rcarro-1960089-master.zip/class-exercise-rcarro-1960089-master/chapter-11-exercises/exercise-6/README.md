# Exercise 6
In this exercise, you'll practice using the dplyr's join functions on the [`nycflights13`](https://cran.r-project.org/web/packages/nycflights13/index.html) data set.

To complete the exercise, open the `exercise-6/exercise.R` file in RStudio, and follow the instructions there.
