# Exercise 7
In this exercise, you'll practice using the dplyr's library to work with an external data set, specifically NBA team statistics from the 2015-2016 season.

To complete the exercise, open the `exercise-7/exercise.R` file in RStudio, and follow the instructions there.
