# Exercise 8
In this exercise, you'll practice using dplyr to explore a data set, specifically information about _Pulitzer Prize Winning Newspapers_. The dataset comes from [Five Thirty Eight.](https://github.com/fivethirtyeight/data/blob/master/pulitzer/pulitzer-circulation-data.csv). More information on the [Pulitzer Prize](http://www.pulitzer.org/) can be found on their website.

To complete the exercise, open the `exercise-8/exercise.R` file in RStudio, and follow the instructions there.
