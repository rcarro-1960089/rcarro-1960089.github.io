# Chapter 11 Exercises

This repository contains programming exercises for using the `tidyr` library to wrangle data,
based on Chapter 12 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.