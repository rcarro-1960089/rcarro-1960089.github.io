# Exercise 1
In this exercise, you'll practice accessing an SQLite database. Specifically, you'll be working with the popular [Chinook Database](https://github.com/lerocha/chinook-database), a free sample database that models an iTunes music library.

To complete the exercise, open the `exercise-1/exercise.R` file in RStudio, and follow the instructions there.
