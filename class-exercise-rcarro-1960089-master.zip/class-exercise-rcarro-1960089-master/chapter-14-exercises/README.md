# Chapter 14 Exercises

This repository contains programming exercises for accessing web APIs using R,
based on Chapter 14 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.