# Chapter 16 Exercises

This repository contains programming exercises for generated data visualizations with the [`ggplot2`](http://ggplot2.tidyverse.org/) library,
based on Chapter 16 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).

Solutions can be found in the `solution` branch.