# Exercise 1
In this exercise, you'll practice using the `ggplot2` library and the Grammar of Graphics to create basic visualizations.

To complete the exercise, open the `exercise-1/exercise.R` file in RStudio, and follow the instructions there.
