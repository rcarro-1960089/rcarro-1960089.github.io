# Exercise 2
In this exercise, you'll practice using the `ggplot2` library and the Grammar of Graphics to create more advanced data visualizations.

To complete the exercise, open the `exercise-2/exercise.R` file in RStudio, and follow the instructions there.
