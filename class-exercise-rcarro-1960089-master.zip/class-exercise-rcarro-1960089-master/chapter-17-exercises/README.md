# Chapter 17 Exercises

This repository contains programming exercises for building interactive visualizations using the `plotly`, `rbokeh` and `leaflet` packages, based on Chapter 17 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.