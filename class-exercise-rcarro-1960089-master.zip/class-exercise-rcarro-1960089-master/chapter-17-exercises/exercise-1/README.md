# Exercise-1
In this exercise, you will use the `plotly` package to create a grouped bar chart of cancer (neoplasm) mortality rates in King County, Washington using data from [IHME](http://www.healthdata.org/). 

Follow the instructions in the `exercise.R` file to create the graphic below:

![alt text](imgs/exercise-1-plot.png)

Follow See the `solution` branch for solutions. 
