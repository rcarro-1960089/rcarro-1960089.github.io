# Chapter 18 Exercises

This repository contains programming exercises for generated data reports using R Markdown,
based on Chapter 18 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 
Solutions can be found in the `solution` branch.