# Chapter 19 Exercises

This repository contains programming exercises for generating interactive data apps with the [`shiny`](https://shiny.rstudio.com/) framework,

based on Chapter 19 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).

Solutions can be found in the `solution` branch.