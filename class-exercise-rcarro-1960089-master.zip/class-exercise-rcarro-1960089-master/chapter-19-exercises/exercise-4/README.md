# Exercise 4
In this exercise, you'll practice creating Shiny apps with more complex layouts and content elements:

![Example income growth chart](img/example.png)

To complete the exercise, open the `exercise-4/app.R` and `exercise-4/app_ui.R` files in RStudio, and follow the instructions there. Note that server code has already been provided for you (in the `app_server.R` file).
