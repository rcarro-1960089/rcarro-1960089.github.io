# Chapter 20 Exercises

This repository contains programming exercises for working with _branches_ in git,
based on Chapter 20 of [_Programming Skills for Data Science_](https://programming-for-data-science.github.io/).
 